import uuid


class ExtractNmapResult():

    def __init__(self, type, xml_fpath):
        self.type = type
        self.xml_fpath = xml_fpath


    def sP(self):
        """
        存活主机的检测; 全部写入
        :return:
        """

from cso.models import SysManagerCopInfo, HostService, NmapTaskAuditLog, ConnectManagerUserInfo


def create_cop_default_user(name="普通KVM默认用户", username="root", password="111111"):
    _user = ConnectManagerUserInfo.objects.create(
        name = name,
        username = username,
        _password = password,
    )
    return _user


def run():
    #create_cop_default_user()
    HostService.objects.all().delete()

    file_path = "F:\\workspace\\CSO\\cso\\datas\\nmap_results\\sV.xml"
    from cso.mudules.monitor.nmap_utils.trans import NmapUtil
    datas = NmapUtil.get_data_info(file_path)

    push_time = datas["push_time"]
    results = datas["results"]
    nmap_args = datas["nmap_args"]

    from xsqlmb.src.ltool.utils.dt_tool import get_pydt_based_logdt, get_pydt2_based_nmap
    _time = get_pydt2_based_nmap(push_time)

    _log = NmapTaskAuditLog(
        run_time=_time,
        run_script = nmap_args,
        saved_path = file_path,
    )

    import uuid
    hostServices = []
    for result in results:
        sV_info = result["sV_info"]
        sP_info = result["sP_info"]
        O_info = result["O_info"]

        if sP_info["mac"] in [x.mac for x in SysManagerCopInfo.objects.all()]:
            cop = SysManagerCopInfo.objects.filter(mac=sP_info["mac"])[0]
        else:
            cop = SysManagerCopInfo(
                uniq_flag="CommonHost" + str(uuid.uuid4()),
                name=sP_info["ip"],
                ip=sP_info["ip"],
                type="自发现设备",
                os=O_info["os"] if "os" in O_info.keys() else "Centos-7.4",
                mac=sP_info["mac"],
                mac_vendor=sP_info["mac_vendor"],
                up=True,
            )
            cop.save()
            cop.managers.add(ConnectManagerUserInfo.objects.filter(username="root")[0])

        if "services" in sV_info.keys():
            for services in sV_info["services"]:
                hs = HostService(
                    **services,
                    descover_time=_time,
                    belongCop=cop
                )
                hostServices.append(hs)
    HostService.objects.bulk_create(hostServices)








