import os, xmltodict


if __name__ == '__main__':
    file_path = "F:\\workspace\\CSO\\cso\\datas\\nmap_results\\O.xml"
    datas = get_data_info(file_path)
    print(datas)
