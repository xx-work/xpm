import xmltodict
from website.plat_settings.monitor_settings import NmapBin, DataDir

NmapTypes = [
    {"name": "操作系统探测", "args": "-O", "result_path": "O.xml" },
    {"name": "服务探测", "args": "-sS -sV -v", "result_path": "O.xml" },
    {"name": "主机存货探测", "args": "-sP", "result_path": "O.xml" },

]


class NmapUtil():

    def __init__(self, type=None, targets=None, ports="1-65535"):
        """
        Nmap 扫描工具
        :param type: 探测的类型
        :param targets:  探测的目标
        """
        self.type = type
        self.targets = targets
        self.ports = ports

    def get_nmap_shells(self):
        try:
            _obj = [x for x in NmapTypes if x["name"] == self.type][0]
        except:
            return None

        return "{NmapBin} {args} {ports} {targets} -oX {result_path}".format(
                NmapBin=NmapBin,
                args=_obj["args"],
                ports=self.ports if self.type=="服务探测" else "",
                targets=_obj["targets"],
                result_path=_obj["result_path"]
        )


    @staticmethod
    def get_data_info(path):
        with open(path, "r+", encoding="utf-8") as f:
            try:
                xml = f.read()
            finally:
                f.close()

        datas = xmltodict.parse(xml)["nmaprun"]
        push_time = datas["@startstr"]
        nmap_args = datas["@args"]
        hosts_datas = datas["host"]

        results = []

        for host_datas in hosts_datas:
            sP_info = {}
            O_info = {}
            sV_info = {}

            if "address" in host_datas.keys():
                try:
                    host_info = host_datas["address"]
                    if type(host_info) != type([]):
                        continue
                    host_ip = [x["@addr"] for x in host_info if x["@addrtype"] == 'ipv4'][0]
                    host_mac = [x["@addr"] for x in host_info if x["@addrtype"] == 'mac'][0]
                    try:
                        mac_vendor = [x["@vendor"] for x in host_info if x["@addrtype"] == 'mac'][0]
                    except:
                        mac_vendor = "-"
                    sP_info.setdefault("mac", host_mac)
                    sP_info.setdefault("mac_vendor", mac_vendor)
                    sP_info.setdefault("ip", host_ip)
                    sP_info.setdefault("up", True)
                    # hosts_discover.append(sp_info)
                except:
                    pass

            if "os" in host_datas.keys():
                try:
                    os_info = host_datas["os"]['osmatch']
                    host_os = [x["@name"] for x in os_info][0]
                    O_info["ip"] = host_ip
                    O_info["os"] = host_os
                    # os_sets.append(_info)
                except:
                    pass

            if "ports" in host_datas.keys():
                try:
                    port_info = host_datas["ports"]
                    services = []
                    for k, value in port_info.items():
                        if "port" == k:
                            for x in value:
                                _temp = {}
                                # 开始格式化我们自己的端口服务信息
                                _temp["port"] = x["@portid"] if "@portid" in x.keys() else "0"
                                _temp["protocol"] = x["@protocol"] if "@protocol" in x.keys() else "ptl"
                                _temp["state"] = x["@state"] if "@state" in x.keys() else "open"
                                # _temp["service"]= x["service"] if "service" in x.keys() else {}
                                _serv = x["service"]

                                if "@product" in _serv.keys():
                                    app_version = _serv["@product"] + " " + _serv[
                                        "@version"] if "@version" in _serv.keys() \
                                        else _serv["@product"]
                                else:
                                    app_version = "unknown version"

                                services.append(dict(
                                    service=_serv["@name"],
                                    version=app_version,
                                    state=_temp["state"],
                                    port=_temp["port"],
                                    protocol=_temp["protocol"],
                                    hostname=host_ip
                                ))
                    sV_info["services"] = services

                except:
                    # print(host_datas[KEY].keys())
                    pass
            results.append(dict(
                    sV_info=sV_info,
                    sP_info=sP_info,
                    O_info=O_info
            ))

        return dict(
            nmap_args=nmap_args,
            results=results,
            push_time=push_time
        )


