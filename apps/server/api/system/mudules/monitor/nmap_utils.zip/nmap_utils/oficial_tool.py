from libnmap.parser import NmapParser


path = "F:\\workspace\\CSO\\apps\\cso\\datas\\nmap_results\\sV.xml"

def get_report_from_nmap_xml(xml_path):
    return NmapParser.parse_fromfile(xml_path, )

# https://libnmap.readthedocs.io/en/latest/objects/nmapreport.html

if __name__ == '__main__':
    result = get_report_from_nmap_xml(path)

    print()
    for _host in result.hosts:
        print(_host.ipv4 + "==============\n")
        print(_host.mac + "==============\n")
        print(_host.os)
        for _service in _host.services:
            print(_service.get_dict())


