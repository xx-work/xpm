
DefaultConfig = dict(
    min_sys_scan_period=300,
    min_process_scan_period=300,
    min_log_saved_period=180,

    set_sys_scan_period=180,
    set_process_scan_period=180,
    set_log_saved_period=200,


)